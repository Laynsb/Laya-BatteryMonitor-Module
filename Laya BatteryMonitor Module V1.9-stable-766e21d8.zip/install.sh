#!/bin/sh
SKIPMOUNT=false
PROPFILE=false
POSTFSDATA=false
LATESTARTSERVICE=true
REPLACE=""
ui_print "- Extracting module files"
unzip -p "$ZIPFILE" 'battmon' >"$MODPATH/laya.battmon-service"
chmod +x "$MODPATH/laya.battmon-service"
