#!/system/bin/sh

#### LaynsbProject Property ###
### DO NOT MODIFY OR REMOVE ###
# allow read/write access to CPUFreq scaling_* files
# shell code by @rianixia, modified by laynsb for wide compatibility
while [ "$(getprop sys.boot_completed)" != "1" ]; do
    sleep 1
done

if [ -d "/data/adb/modules/encore" ]; then
    sleep 50
fi

FILES="
scaling_available_frequencies
scaling_available_governors
scaling_cur_freq
scaling_driver
scaling_governor
scaling_max_freq
scaling_min_freq
scaling_setspeed
"

get_cpu_policy_paths() {
    find /sys/devices/system/cpu/ -type d \( -name "cpufreq" -o -name "cpufreq/cpu0" \) 2>/dev/null |
        grep -E "cpufreq(/policy[0-9]+)?$"
}

chmod_scaling() {
    for dir in $(get_cpu_policy_paths); do
        for file in $FILES; do
            path="$dir/$file"
            if [ -e "$path" ]; then
                chmod 0664 "$path"
            fi
        done
    done
}

need_retry() {
    for dir in $(get_cpu_policy_paths); do
        for file in $FILES; do
            path="$dir/$file"
            if [ -e "$path" ]; then
                perms=$(stat -c "%a" "$path")
                if [ "$perms" = "444" ]; then
                    return 0
                fi
            fi
        done
    done
    return 1
}

retry_chmod_if_needed() {
    local retries=0
    while [ "$retries" -lt 3 ]; do
        if need_retry; then
            sleep 3
            chmod_scaling
            retries=$((retries + 1))
        else
            break
        fi
    done
}

chmod_scaling
retry_chmod_if_needed

# Stop existing process immediately after boot
if [ "$(getprop init.svc.laya_battmon)" = "running" ]; then
    stop laya_battmon
fi

if [ "$(getprop init.svc.laya_battmon_svc)" = "running" ]; then
    stop laya_battmon_svc
fi

# battmon dynamic toggle
setprop debug.laya.battmon_enabled 1

# Start module
sleep 1
/data/adb/modules/battmontester/laya.battmon-service
